import discord
from discord.ext import commands
import os

# ---------------------- CONFIG ----------------------
TOKEN = "MTQzNDIwMzMyODk2Mjc2MDk2Ng.G9YthB.dt2aENj_o1ZY0dVt-1VweLIrOLY0kvqbWIzcJ8"  # <-- Replace with your bot token directly
TARGET_STATUS = "CHEAP ROBUX: https://discord.gg/jvMFbYGXtk"        # Word or number to check for
ROLE_ID = 1434205236372832297    # Replace with your role ID (as an integer)
# ----------------------------------------------------

intents = discord.Intents.default()
intents.members = True
intents.presences = True  # Needed to read status

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.event
async def on_presence_update(before: discord.Member, after: discord.Member):
    if after.guild is None:
        return

    # Look for custom status
    custom_status = None
    for activity in after.activities:
        if isinstance(activity, discord.CustomActivity):
            custom_status = activity.name  # Use .state for text if .name is None
            break

    role = after.guild.get_role(ROLE_ID)
    if role is None:
        print("Role not found!")
        return

    # Add role if status matches
    if custom_status == TARGET_STATUS:
        if role not in after.roles:
            try:
                await after.add_roles(role)
                print(f"Added role to {after.display_name}")
            except Exception as e:
                print(f"Error adding role: {e}")
    # Remove role if status no longer matches
    else:
        if role in after.roles:
            try:
                await after.remove_roles(role)
                print(f"Removed role from {after.display_name}")
            except Exception as e:
                print(f"Error removing role: {e}")

# Run the bot
bot.run(TOKEN)

