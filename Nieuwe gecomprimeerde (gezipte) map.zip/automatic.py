# bot.py
import discord
from discord.ext import commands
from discord.ui import Button, View
import json
import os

# ---------------- CONFIG ----------------
TOKEN = "MTQzNDY5MjkyOTczNzQ2MTg2Mg.GAstal.FpksN6Pj5GK8Qm0bbpiOJ4zxNIkmBnLyM5y9a8"  # <-- Put your actual bot token here
CHANNEL_ID = 1432863250105765888
OWNER_IDS = [
    1434692929737461862,
    1261327532184047628,
]

PERSIST_FILE = "button_message.json"  # stores the message ID

# ---------------- BOT SETUP ----------------
intents = discord.Intents.default()
intents.guilds = True
intents.messages = True
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# ---------------- BUTTON VIEW ----------------
class OrderButtonView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Begin Automatic Order",
        style=discord.ButtonStyle.primary,
        custom_id="begin_automatic_order"
    )
    async def begin_order(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)  # user sees ephemeral reply
        channel = interaction.channel

        if not isinstance(channel, discord.TextChannel):
            await interaction.followup.send("Cannot create a thread in this channel.", ephemeral=True)
            return

        thread_name = f"Order-{interaction.user.name}-{interaction.user.discriminator}"

        try:
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                auto_archive_duration=1440,
                reason=f"Automatic order thread created by {interaction.user}",
            )
        except Exception as e:
            await interaction.followup.send(f"Failed to create private thread: {e}", ephemeral=True)
            return

        # Add the user who clicked the button
        try:
            await thread.add_user(interaction.user)
        except Exception:
            pass  # silently fail if can't add

        # Add the owners
        for owner_id in OWNER_IDS:
            try:
                member = await interaction.guild.fetch_member(owner_id)
                await thread.add_user(member)
            except Exception:
                pass  # silently fail

        # Do NOT send any message in the original channel
        # Optionally, you can send a message inside the thread itself if needed:
        # await thread.send("Thread created.")  # optional

        # Send a small ephemeral reply to the user so they know the thread exists
        await interaction.followup.send(f"Private thread **{thread.name}** created.", ephemeral=True)

# ---------------- HELPER FUNCTIONS ----------------
def load_message_id():
    if os.path.exists(PERSIST_FILE):
        try:
            with open(PERSIST_FILE, "r") as f:
                return json.load(f).get("message_id")
        except Exception:
            return None
    return None

def save_message_id(message_id):
    with open(PERSIST_FILE, "w") as f:
        json.dump({"message_id": message_id}, f)

# ---------------- ON READY ----------------
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")

    channel = bot.get_channel(CHANNEL_ID)
    if channel is None:
        print(f"Channel ID {CHANNEL_ID} not found.")
        return

    view = OrderButtonView()
    bot.add_view(view)

    marker_text = "Click the button to begin an automatic order:"
    message_id = load_message_id()
    message_obj = None

    if message_id:
        try:
            message_obj = await channel.fetch_message(message_id)
            await message_obj.edit(view=view)
            print(f"Re-attached view to existing button message (ID: {message_id})")
        except discord.NotFound:
            print("Previously saved message was deleted. Sending a new one.")
            message_obj = None
        except Exception as e:
            print(f"Error fetching previous message: {e}")
            message_obj = None

    if not message_obj:
        try:
            sent = await channel.send(marker_text, view=view)
            save_message_id(sent.id)
            print(f"Sent new button message (ID: {sent.id})")
        except Exception as e:
            print(f"Failed to send button message: {e}")

# ---------------- RUN BOT ----------------
if __name__ == "__main__":
    bot.run(TOKEN)
