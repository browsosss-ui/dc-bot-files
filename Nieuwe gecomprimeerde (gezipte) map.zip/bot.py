import discord
from discord.ext import commands
import asyncio
import random
from datetime import datetime, timedelta

# ------------------------------
# CONFIG
# ------------------------------

TOKEN = "MTQzMzUxOTA5MjU4MDYxNDIzNg.GYr_F3.JBH4xz0KAjFdNVN_BS_mwHGQLkT9c_5h8cWvGE"  # <-- replace with your new token (reset it first!)
CHANNEL_ID = 1431788049150513255  # <-- replace with your actual channel ID
AUTOMESSAGE = "test"

INTERVAL_MINUTES = 67  # <-- Change this to set how often (in minutes) the bot should send a message

# ------------------------------
# BOT SETUP
# ------------------------------

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


# ------------------------------
# BACKGROUND TASK
# ------------------------------

async def periodic_message():
    """Sends one message per interval, at a random time within each interval block."""
    await bot.wait_until_ready()
    while not bot.is_closed():
        now = datetime.utcnow()

        # Determine start of current interval block
        block_length = timedelta(minutes=INTERVAL_MINUTES)
        blocks_since_start = int((now.minute + now.hour * 60) / INTERVAL_MINUTES)
        block_start = datetime(
            year=now.year, month=now.month, day=now.day,
            hour=(blocks_since_start * INTERVAL_MINUTES) // 60,
            minute=(blocks_since_start * INTERVAL_MINUTES) % 60,
            second=0, microsecond=0
        )

        # Choose random time within the current block
        offset_seconds = random.randint(0, INTERVAL_MINUTES * 60 - 1)
        send_time = block_start + timedelta(seconds=offset_seconds)

        # If that time already passed, schedule for the next block
        if send_time <= now:
            next_block_start = block_start + block_length
            send_time = next_block_start + timedelta(seconds=random.randint(0, INTERVAL_MINUTES * 60 - 1))

        wait_seconds = (send_time - now).total_seconds()
        print(f"[AutoMsg] Next message scheduled for {send_time.isoformat()} UTC (waiting {int(wait_seconds)}s)")

        try:
            await asyncio.sleep(wait_seconds)
        except asyncio.CancelledError:
            break

        try:
            channel = bot.get_channel(CHANNEL_ID)
            if channel is None:
                channel = await bot.fetch_channel(CHANNEL_ID)
            await channel.send(AUTOMESSAGE)
            print(f"[AutoMsg] Message sent at {datetime.utcnow().isoformat()} UTC")
        except Exception as e:
            print(f"[AutoMsg] Error sending message: {e}")


# ------------------------------
# EVENTS & COMMANDS
# ------------------------------

@bot.event
async def on_ready():
    print(f"✅ Bot is online as: {bot.user}")
    bot.loop.create_task(periodic_message())


@bot.command()
async def say(ctx, *, tekst: str):
    """Manual command: !say your message"""
    await ctx.send(tekst)


# ------------------------------
# START BOT
# ------------------------------

bot.run(TOKEN)



